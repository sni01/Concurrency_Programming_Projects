#ifndef _CART_
#define _CART_


struct cart_t {
  int num;       /* number of this cart */
  char dir;      /* direction from which this cart arrives at intersection */
};


#endif /* _CART_ */
